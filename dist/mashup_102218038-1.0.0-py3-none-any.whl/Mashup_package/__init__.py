from Mashup_package.download import download
from Mashup_package.download import find_link
from Mashup_package.download import download_all
from Mashup_package.download import mashup